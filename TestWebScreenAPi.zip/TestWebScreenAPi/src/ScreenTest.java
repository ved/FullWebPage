import org.apache.commons.validator.routines.UrlValidator;

import com.ved.screen.WebPage;

public class ScreenTest {

	
	public static boolean urlValidator(String url)
	{
		// Get an UrlValidator using default schemes
		UrlValidator defaultValidator = new UrlValidator();
		return defaultValidator.isValid(url);
	}

	public static void main(String[] args)
	{
		String url = "https://en.wikipedia.org/wikiRatan_Tata";

		// Validate an url
		if (urlValidator(url)) {
			WebPage.getFullScreen(url);
			}
		else {
			System.out.print("The url " + url + " isn't valid");
		}
	}

}
